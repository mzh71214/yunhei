<?php
$host = 'localhost'; //数据库地址
$port = 3306; //端口
$user = ''; //用户名
$pwd = ''; //密码
$dbname = ''; //数据库名
?>